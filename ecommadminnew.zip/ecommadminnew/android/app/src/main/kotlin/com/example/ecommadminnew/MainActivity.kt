package com.example.ecommadminnew

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
