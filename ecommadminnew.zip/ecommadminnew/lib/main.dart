import 'package:flutter/material.dart';
import 'package:ecommadminnew/screens/admin.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Admin(),
  ));
}